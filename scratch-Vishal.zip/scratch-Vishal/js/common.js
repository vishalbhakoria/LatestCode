﻿/* new script */
$('#divErrorId').hide();

function onSubmit() {
    $('#lblErrorMsg').text('');


    if ($('#id_input').val() == null || $('#id_input').val() == "") {
        $('#lblErrorMsg').text('Please enter NRIC No.')
        $('#id_input').css('border-color', 'red');
        $('#divErrorId').show();
        return;
    }
    if ($('#id_input').val().length <= 3) {
        $('#lblErrorMsg').text('Please enter correct NRIC No.')
        $('#id_input').css('border-color', 'red');
        $('#divErrorId').show();
        return;
    }

    window.location.replace('landing.html')
}

function onPayTax() {
    window.location.replace('payment.html')
}


function onAXSPage() {
    window.location.replace('pin.html')
}

function onBack() {
    window.location.replace('landing.html')
}



function onOCBCBank() {
    var r = confirm("You will be leaving IRAS website and be re-directed to external page.");
    if (r == true) {
        window.open('https://internet.ocbc.com/internet-banking/');
    } else {
        return;
    }
}
function onDBSBank() {
    var r = confirm("You will be leaving IRAS website and be re-directed to external page.");
    if (r == true) {
        window.open('http://www.dbs.com.sg');
    } else {
        return;
    }
}
function onPOSBBank() {
    var r = confirm("You will be leaving IRAS website and be re-directed to external page.");
    if (r == true) {
        window.open('http://www.dbs.com.sg');
    } else {
        return;
    }
}
function onUOBBank() {
    var r = confirm("You will be leaving IRAS website and be re-directed to external page.");
    if (r == true) {
        window.open('http://www.uobgroup.com.sg');
    } else {
        return;
    }
}

//function onCopy() {
//    var copyText = document.getElementById("myInput");
//    copyText.select();
//    copyText.setSelectionRange(0, 99999)
//    document.execCommand("copy");
//}


function onCopy() {
    var copyText = document.getElementById("myInput");
    //myInput.innerText = document.getElementById("lblRefNo");
    //var copyText = myInput.innerText;
    copyText.select();
    copyText.setSelectionRange(0, 99999)
    document.execCommand("copy");
    copyText.blur();
}

function onAskJamie() {
    window.open('https://va.ecitizen.gov.sg/CFP/VA/IRAS/PTSD/mobile.html?PageTitle=Property%20Tax%20Interactive%20Bill');
}

function onViewIBill() {
    window.open('https://mytax.iras.gov.sg/ESVWeb/default.aspx');
}

$(document).ready(function () {
    //$('#myInput').hide();

    $('[data-toggle="popover"]').popover();
});

$(function () {
    $('#copytext').on('hide.bs.popover', function (e) {
        onCopy();
    });
});
$('.popover-dismiss').popover({
    trigger: 'focus'
})



