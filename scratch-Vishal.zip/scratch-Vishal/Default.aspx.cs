﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        setSessionValuestoVariables();
    }


    private void setSessionValuestoVariables()
    {
        Label1.text =  Session[""].ToString();
        Label2.text = Session[""].ToString();
        Label3.text = Session[""].ToString();
        Label4.text = Session[""].ToString();
        Label5.text = Session[""].ToString();
    }
}